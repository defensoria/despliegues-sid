--executer user admin

grant create view to SID;