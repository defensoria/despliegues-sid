/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.com.simco.defensoria.dao;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pe.com.simco.defensoria.model.Canal;

/**
 *
 * @author carlos
 */
public class CanalDAOImplTest {
    
    public CanalDAOImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of listaCanales method, of class CanalDAOImpl.
     */
    @Test
    public void testListaCanales() {
        System.out.println("listaCanales");
        CanalDAOImpl instance = new CanalDAOImpl();
        List<Canal> expResult = null;
        List<Canal> result = instance.listaCanales();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
