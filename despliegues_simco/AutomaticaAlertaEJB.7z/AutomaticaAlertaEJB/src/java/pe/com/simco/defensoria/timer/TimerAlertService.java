/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.com.simco.defensoria.timer;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import pe.com.simco.defensoria.model.Alerta;
import pe.com.simco.defensoria.model.SeguimientoAcuerdo;
import pe.com.simco.defensoria.service.AlertaService;
import pe.com.simco.defensoria.service.SeguimientoAcuerdoService;

/**
 *
 * @author carlos
 */
@Stateless
public class TimerAlertService implements Serializable {

    @EJB
    private SeguimientoAcuerdoService seguimientoAcuerdoService;

    @EJB
    private AlertaService alertaService;

    @Schedule(second = "0", minute = "25", hour = "13")
    public void envioAutomaticoAlertas() {
        Date hoy = new Date();
        List<SeguimientoAcuerdo> list = seguimientoAcuerdoService.listarPendientes();

        for (SeguimientoAcuerdo seguimientoAcuerdo : list) {
            if (seguimientoAcuerdo != null) {
                if (seguimientoAcuerdo.getInicioDefinitivo() != null && seguimientoAcuerdo.getFinDefinitivo() != null) {
                    try {
                        if (seguimientoAcuerdo.getInicioDefinitivo().before(hoy)) {
                            if (sumarRestarDiasFecha(seguimientoAcuerdo.getFinDefinitivo(), 1).after(hoy)) {
                                Alerta alerta = new Alerta();
                                alerta.setFechaEnvio(new Date());
                                alerta.setDescripcion("Nueva Alerta");
                                alerta.setId(null);
                                alerta.setEstado("PEN");
                                alerta.setSeguimientoAcuerdo(seguimientoAcuerdo);
                                alertaService.saveAlerta(alerta);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public Date sumarRestarDiasFecha(Date fecha, int dias) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fecha); 
        calendar.add(Calendar.DAY_OF_YEAR, dias);	
        return calendar.getTime();
    }

}
