/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pe.com.simco.defensoria.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author carlos
 */
@Entity
@Table(name="SIMCO_SEG_ACUERDOS")
public class SeguimientoAcuerdo implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="N_ID_SEGUIEMIENTO")
    private Long id;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="D_FECINISEGUIMIENTOFINAL")
    private Date inicioDefinitivo;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="D_FECFINSEGUIMIENTOFINAL")
    private Date finDefinitivo;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="D_ULTIMAEJECUCION")
    private Date ultimaEjecucion;
    
    @Column(name="C_ESTADOSEGUIMIENTO")
    private String estado;
            
    @Column(name="C_DESTINAOPCIONALES")
    private String opcionales;
    
    @Transient
    private Date inicio;
    
    @Transient
    private Date fin;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getInicioDefinitivo() {
        return inicioDefinitivo;
    }

    public void setInicioDefinitivo(Date inicioDefinitivo) {
        this.inicioDefinitivo = inicioDefinitivo;
    }

    public Date getFinDefinitivo() {
        return finDefinitivo;
    }

    public void setFinDefinitivo(Date finDefinitivo) {
        this.finDefinitivo = finDefinitivo;
    }

    public Date getUltimaEjecucion() {
        return ultimaEjecucion;
    }

    public void setUltimaEjecucion(Date ultimaEjecucion) {
        this.ultimaEjecucion = ultimaEjecucion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getOpcionales() {
        return opcionales;
    }

    public void setOpcionales(String opcionales) {
        this.opcionales = opcionales;
    }

    public Date getInicio() {
        return inicio;
    }

    public void setInicio(Date inicio) {
        this.inicio = inicio;
    }

    public Date getFin() {
        return fin;
    }

    public void setFin(Date fin) {
        this.fin = fin;
    }

}
