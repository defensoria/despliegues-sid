package pe.gob.osce.seace.contratos.service;

import java.util.List;

import pe.gob.osce.seace.contratos.model.Expediente;

public interface ExpedienteService {
	
	List<Expediente> listadoExpediente();

}
