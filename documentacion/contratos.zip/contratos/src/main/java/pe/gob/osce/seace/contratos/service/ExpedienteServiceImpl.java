package pe.gob.osce.seace.contratos.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.osce.seace.contratos.dao.ExpedienteDAO;
import pe.gob.osce.seace.contratos.model.Expediente;

@Service
public class ExpedienteServiceImpl implements ExpedienteService{
	
	@Autowired
	private ExpedienteDAO expedienteDAO;

	@Override
	public List<Expediente> listadoExpediente() {
		return (List<Expediente>) expedienteDAO.findAll();
	}

}
