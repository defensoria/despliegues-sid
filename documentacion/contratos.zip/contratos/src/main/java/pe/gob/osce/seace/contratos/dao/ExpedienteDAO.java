package pe.gob.osce.seace.contratos.dao;

import org.springframework.data.repository.CrudRepository;

import pe.gob.osce.seace.contratos.model.Expediente;

public interface ExpedienteDAO extends CrudRepository<Expediente, Long>{

}
